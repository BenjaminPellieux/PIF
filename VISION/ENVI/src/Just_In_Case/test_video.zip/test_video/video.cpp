#include <iostream>
#include <opencv2/opencv.hpp>
#include <linux/videodev2.h>

using namespace cv;

int main() {
    // Initialiser la capture vidéo depuis la webcam avec le backend V4L
    cv::VideoCapture cap(0, cv::CAP_V4L);
   
    std::cout<<"test 1\n";
    // Vérifier si la capture vidéo est ouverte
    if (!cap.isOpened()) {
        std::cerr << "Erreur lors de l'ouverture de la webcam." << std::endl;
        return -1;
    }

    while (true) {
	
	std::cout<<"test 2\n";
        // Capturer une image depuis la webcam
        Mat src;
        cap >> src;

        // Vérifier si l'image est correctement capturée
        if (src.empty()) {
            std::cerr << "Erreur lors de la capture de l'image depuis la webcam." << std::endl;
            break;
        }

        // ... (restez inchangé)

        // Attendre une petite période et vérifier si une touche est pressée
        if (waitKey(30) >= 0)
            break;
    }

    // Fermer la fenêtre et libérer la capture vidéo
    destroyAllWindows();
    cap.release();

    return 0;
}
